"""
cube_engine.py
--------------
A cube defined as 8 vertices + 12 edges, transformed with hand-rolled
rotation / scale / translation matrices (plain numpy, no OpenGL) and
projected to 2D screen space with a simple perspective projection.
"""

import numpy as np


class CubeEngine:
    def __init__(self, size=1.0):
        s = size / 2.0
        # 8 corners of a cube centered on the origin.
        self.base_vertices = np.array([
            [-s, -s, -s],  # 0
            [ s, -s, -s],  # 1
            [ s,  s, -s],  # 2
            [-s,  s, -s],  # 3
            [-s, -s,  s],  # 4
            [ s, -s,  s],  # 5
            [ s,  s,  s],  # 6
            [-s,  s,  s],  # 7
        ], dtype=np.float64)

        # Pairs of vertex indices that form the cube's 12 edges.
        self.edges = [
            (0, 1), (1, 2), (2, 3), (3, 0),  # back face
            (4, 5), (5, 6), (6, 7), (7, 4),  # front face
            (0, 4), (1, 5), (2, 6), (3, 7),  # connecting edges
        ]

        self.rot_x = 0.0
        self.rot_y = 0.0
        self.rot_z = 0.0
        self.scale = 1.0
        self.translation = np.array([0.0, 0.0, 0.0])

    def set_transform(self, rot_x_deg, rot_y_deg, rot_z_deg, scale, translation=None):
        self.rot_x = rot_x_deg
        self.rot_y = rot_y_deg
        self.rot_z = rot_z_deg
        self.scale = max(0.05, scale)
        if translation is not None:
            self.translation = np.array(translation, dtype=np.float64)

    @staticmethod
    def _rot_matrix_x(deg):
        a = np.radians(deg)
        c, s = np.cos(a), np.sin(a)
        return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])

    @staticmethod
    def _rot_matrix_y(deg):
        a = np.radians(deg)
        c, s = np.cos(a), np.sin(a)
        return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])

    @staticmethod
    def _rot_matrix_z(deg):
        a = np.radians(deg)
        c, s = np.cos(a), np.sin(a)
        return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])

    def get_transformed_vertices(self):
        """Apply rotation (Z * Y * X order), then scale, then translation."""
        r = self._rot_matrix_z(self.rot_z) @ self._rot_matrix_y(self.rot_y) @ self._rot_matrix_x(self.rot_x)
        verts = self.base_vertices @ r.T
        verts = verts * self.scale
        verts = verts + self.translation
        return verts

    @staticmethod
    def project(verts_3d, screen_w, screen_h, camera_distance=4.0, focal_length=None):
        """Simple perspective projection: a point further from the camera
        (larger z relative to camera_distance) projects smaller."""
        if focal_length is None:
            focal_length = screen_w * 0.9

        pts2d = np.zeros((len(verts_3d), 2), dtype=np.float64)
        for i, (x, y, z) in enumerate(verts_3d):
            denom = camera_distance - z
            denom = denom if abs(denom) > 1e-6 else 1e-6
            factor = focal_length / denom
            pts2d[i, 0] = x * factor + screen_w / 2.0
            pts2d[i, 1] = -y * factor + screen_h / 2.0
        return pts2d

    def get_screen_edges(self, screen_w, screen_h, camera_distance=4.0):
        """Convenience: returns (projected_2d_points, edge_index_pairs)."""
        verts3d = self.get_transformed_vertices()
        pts2d = self.project(verts3d, screen_w, screen_h, camera_distance)
        return pts2d, self.edges
