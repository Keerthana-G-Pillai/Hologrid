"""
hand_tracker.py
---------------
Thin wrapper around mediapipe.solutions.hands that detects a single hand
per frame and returns its 21 landmarks in the ORIGINAL frame's pixel
coordinate space.

Why the square padding?
MediaPipe's internal landmark_projection_calculator assumes the region
it processes is square. Feeding it a typical non-square webcam frame
(e.g. 640x480) can trigger a "must be square" assertion/crash, or subtly
skew landmark coordinates on the longer axis. To avoid this we letterbox
(pad) the frame to a square with black borders before running it through
MediaPipe, then subtract the padding back out of the returned landmark
coordinates so everything downstream works in the original frame space.
"""

import cv2
import mediapipe as mp


class HandTracker:
    def __init__(self, max_hands=1, detection_confidence=0.6, tracking_confidence=0.6):
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=max_hands,
            min_detection_confidence=detection_confidence,
            min_tracking_confidence=tracking_confidence,
        )

    @staticmethod
    def _pad_to_square(frame):
        """Letterbox `frame` to a square canvas (black borders)."""
        h, w = frame.shape[:2]
        size = max(h, w)
        pad_top = (size - h) // 2
        pad_bottom = size - h - pad_top
        pad_left = (size - w) // 2
        pad_right = size - w - pad_left
        padded = cv2.copyMakeBorder(
            frame, pad_top, pad_bottom, pad_left, pad_right,
            cv2.BORDER_CONSTANT, value=(0, 0, 0),
        )
        return padded, pad_left, pad_top, size

    def process(self, frame):
        """
        Run hand detection on `frame` (BGR image, any aspect ratio).

        Returns a dict:
            landmarks:  list of 21 (x, y) pixel tuples in ORIGINAL frame
                        space, or None if no hand was found
            wrist, thumb_tip, index_tip: convenience (x, y) tuples, or None
            handedness: 'Right' / 'Left' / None
        """
        h, w = frame.shape[:2]
        padded, pad_left, pad_top, size = self._pad_to_square(frame)

        rgb = cv2.cvtColor(padded, cv2.COLOR_BGR2RGB)
        rgb.flags.writeable = False
        results = self.hands.process(rgb)

        output = {
            "landmarks": None,
            "wrist": None,
            "thumb_tip": None,
            "index_tip": None,
            "handedness": None,
        }

        if not results.multi_hand_landmarks:
            return output

        # Prefer a hand MediaPipe has labeled "Right"; otherwise take the
        # first detected hand (max_hands=1 by default anyway).
        chosen_idx = 0
        handedness_label = None
        if results.multi_handedness:
            handedness_label = results.multi_handedness[0].classification[0].label
            for i, hd in enumerate(results.multi_handedness):
                if hd.classification[0].label == "Right":
                    chosen_idx = i
                    handedness_label = "Right"
                    break

        hand_landmarks = results.multi_hand_landmarks[chosen_idx]

        pts = []
        for lm in hand_landmarks.landmark:
            # lm.x / lm.y are normalized [0,1] within the padded square.
            px = lm.x * size - pad_left
            py = lm.y * size - pad_top
            pts.append((px, py))

        output["landmarks"] = pts
        output["wrist"] = pts[self.mp_hands.HandLandmark.WRIST]
        output["thumb_tip"] = pts[self.mp_hands.HandLandmark.THUMB_TIP]
        output["index_tip"] = pts[self.mp_hands.HandLandmark.INDEX_FINGER_TIP]
        output["handedness"] = handedness_label
        return output

    def close(self):
        self.hands.close()
