"""
hologram_render.py
-------------------
Draws the projected cube wireframe as a glowing cyan/green hologram on a
dark background, pure OpenCV (no OpenGL). Adds a receding grid "floor"
for depth cues and a scanline that drifts down the frame each loop for
sci-fi flavor.
"""

import time
import cv2
import numpy as np


class HologramRenderer:
    def __init__(self, width, height):
        self.width = width
        self.height = height

        self.scanline_y = 0.0
        self.scanline_speed = 140.0  # pixels / second
        self._last_time = time.time()

        # Colors are BGR (OpenCV convention).
        self.color_bright = (255, 255, 80)   # bright cyan-white core
        self.color_glow = (200, 160, 0)      # soft cyan/green glow
        self.grid_color = (90, 70, 0)
        self.bg_color = (12, 8, 0)

    # -- internal drawing passes -------------------------------------------------

    def _draw_grid_floor(self, canvas, horizon_y, vanish_x):
        h, w = canvas.shape[:2]

        # Horizontal lines receding toward the horizon.
        n_lines = 10
        for i in range(1, n_lines + 1):
            t = i / n_lines
            y = int(horizon_y + t * (h - horizon_y))
            alpha = max(0.15, 1.0 - t)
            color = tuple(int(c * alpha) for c in self.grid_color)
            cv2.line(canvas, (0, y), (w, y), color, 1, cv2.LINE_AA)

        # Vertical-ish lines converging toward a vanishing point.
        n_verts = 12
        for i in range(n_verts + 1):
            x_top = int(vanish_x + (i - n_verts / 2) * (w / n_verts) * 0.3)
            x_bottom = int(vanish_x + (i - n_verts / 2) * (w / n_verts) * 2.0)
            cv2.line(canvas, (x_top, horizon_y), (x_bottom, h), self.grid_color, 1, cv2.LINE_AA)

    def _draw_scanline(self, canvas, dt):
        h, w = canvas.shape[:2]
        self.scanline_y += self.scanline_speed * dt
        if self.scanline_y > h:
            self.scanline_y = 0.0
        y = int(self.scanline_y)
        overlay = canvas.copy()
        cv2.line(overlay, (0, y), (w, y), (255, 255, 255), 2, cv2.LINE_AA)
        cv2.addWeighted(overlay, 0.25, canvas, 0.75, 0, dst=canvas)

    def _draw_edges_glow(self, canvas, pts2d, edges):
        # Pass 1: thick, semi-transparent lines for the "glow" halo.
        overlay = canvas.copy()
        for (i, j) in edges:
            p1, p2 = pts2d[i], pts2d[j]
            if not (np.all(np.isfinite(p1)) and np.all(np.isfinite(p2))):
                continue
            pt1 = (int(p1[0]), int(p1[1]))
            pt2 = (int(p2[0]), int(p2[1]))
            cv2.line(overlay, pt1, pt2, self.color_glow, 9, cv2.LINE_AA)
        cv2.addWeighted(overlay, 0.35, canvas, 0.65, 0, dst=canvas)

        # Pass 2: thin, bright core lines drawn on top.
        for (i, j) in edges:
            p1, p2 = pts2d[i], pts2d[j]
            if not (np.all(np.isfinite(p1)) and np.all(np.isfinite(p2))):
                continue
            pt1 = (int(p1[0]), int(p1[1]))
            pt2 = (int(p2[0]), int(p2[1]))
            cv2.line(canvas, pt1, pt2, self.color_bright, 2, cv2.LINE_AA)

        # Vertex "nodes".
        for p in pts2d:
            if not np.all(np.isfinite(p)):
                continue
            cv2.circle(canvas, (int(p[0]), int(p[1])), 4, self.color_bright, -1, cv2.LINE_AA)

    # -- public API ----------------------------------------------------------

    def render(self, pts2d, edges, status_text=""):
        now = time.time()
        dt = now - self._last_time
        self._last_time = now

        canvas = np.full((self.height, self.width, 3), self.bg_color, dtype=np.uint8)

        horizon_y = int(self.height * 0.68)
        self._draw_grid_floor(canvas, horizon_y, self.width // 2)
        self._draw_edges_glow(canvas, pts2d, edges)
        self._draw_scanline(canvas, dt)

        if status_text:
            cv2.putText(canvas, status_text, (16, self.height - 16),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, self.color_bright, 1, cv2.LINE_AA)

        return canvas

    def add_pip(self, canvas, raw_frame, pip_w=180, pip_h=135, margin=12):
        """Composite a small picture-in-picture of the raw webcam feed into
        the top-right corner of `canvas`."""
        h, w = canvas.shape[:2]
        pip = cv2.resize(raw_frame, (pip_w, pip_h))
        x0 = w - pip_w - margin
        y0 = margin
        cv2.rectangle(canvas, (x0 - 2, y0 - 2), (x0 + pip_w + 2, y0 + pip_h + 2),
                       self.color_bright, 1, cv2.LINE_AA)
        canvas[y0:y0 + pip_h, x0:x0 + pip_w] = pip
        return canvas
