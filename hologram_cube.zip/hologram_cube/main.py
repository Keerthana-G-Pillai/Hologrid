"""
main.py
-------
Project HoloGrid Builder: control a glowing 3D wireframe cube with your
hand via a webcam. Right hand only. Make a fist and move your hand to
rotate the hologram; pinch thumb and index finger to shrink/grow it.

Controls:
  q / Esc  - quit
"""

import time
import cv2

from hand_tracker import HandTracker
from gesture_logic import GestureProcessor
from cube_engine import CubeEngine
from hologram_render import HologramRenderer


def main():
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 960)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

    if not cap.isOpened():
        print("Could not open webcam.")
        return

    ret, frame = cap.read()
    if not ret:
        print("Could not read a frame from the webcam.")
        cap.release()
        return

    h, w = frame.shape[:2]

    tracker = HandTracker(max_hands=1)
    gestures = GestureProcessor(frame_w=w, frame_h=h)
    cube = CubeEngine(size=1.0)
    renderer = HologramRenderer(width=w, height=h)

    prev_time = time.time()
    fps = 0.0

    print("Project HoloGrid Builder -- press 'q' to quit.")
    print("Make a fist and move your hand to rotate. Pinch thumb/index to scale.")

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                # Camera hiccup: skip this iteration rather than crashing.
                continue
            frame = cv2.flip(frame, 1)

            result = tracker.process(frame)

            if result["landmarks"] is not None:
                state = gestures.update(result["landmarks"])
                status = "GRAB - rotating" if state["grab"] else "OPEN - pinch to scale"
            else:
                # No hand this frame: freeze the cube's transform instead
                # of resetting it or letting anything crash.
                state = gestures.hold()
                status = "no hand detected"

            cube.set_transform(
                rot_x_deg=state["rot_x"],
                rot_y_deg=state["rot_y"],
                rot_z_deg=state["rot_z"],
                scale=state["scale"],
            )

            pts2d, edges = cube.get_screen_edges(w, h, camera_distance=4.0)

            canvas = renderer.render(pts2d, edges, status_text=status)
            canvas = renderer.add_pip(canvas, frame)

            now = time.time()
            dt = now - prev_time
            prev_time = now
            if dt > 0:
                inst_fps = 1.0 / dt
                fps = inst_fps if fps == 0 else 0.9 * fps + 0.1 * inst_fps

            cv2.putText(canvas, f"FPS: {fps:.1f}", (16, 28),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 80), 1, cv2.LINE_AA)
            cv2.putText(canvas, "PROJECT HOLOGRID", (16, 56),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 80), 2, cv2.LINE_AA)

            cv2.imshow("Project HoloGrid Builder", canvas)

            key = cv2.waitKey(1) & 0xFF
            if key in (ord('q'), 27):  # 'q' or Esc
                break
    finally:
        tracker.close()
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
