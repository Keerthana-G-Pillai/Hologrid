"""
gesture_logic.py
-----------------
Turns raw 21-point hand landmarks into smoothed cube-transform parameters:

  rot_x, rot_y  - tilt, derived from wrist position relative to frame center
  rot_z         - roll, derived from the wrist -> middle-MCP vector angle
  scale         - derived from the thumb-index pinch distance (normalized
                   by hand size so it doesn't depend on distance to camera)
  grab          - True when the hand is a closed fist

Interaction design: rotation only updates while the hand is a closed fist
("grab"), so it feels like physically grabbing the hologram and turning it.
Opening the hand freezes rotation in place. Scale/pinch updates continuously
whenever a hand is visible, regardless of grab state.

Every continuous value is smoothed with an exponential moving average
(EMA: smoothed = (1 - alpha) * prev + alpha * new) to remove per-frame
landmark jitter.
"""

import math
import numpy as np


class EMA:
    def __init__(self, alpha=0.3, initial=None):
        self.alpha = alpha
        self.value = initial

    def update(self, new_value):
        if self.value is None:
            self.value = new_value
        else:
            self.value = (1 - self.alpha) * self.value + self.alpha * new_value
        return self.value


class GestureProcessor:
    # MediaPipe hand landmark indices we care about.
    WRIST = 0
    THUMB_TIP = 4
    INDEX_MCP = 5
    INDEX_TIP = 8
    MIDDLE_MCP = 9
    MIDDLE_TIP = 12
    RING_MCP = 13
    RING_TIP = 16
    PINKY_MCP = 17
    PINKY_TIP = 20

    def __init__(self, frame_w, frame_h, alpha=0.3, max_angle=55.0):
        self.frame_w = frame_w
        self.frame_h = frame_h
        self.max_angle = max_angle

        self.ema_rot_x = EMA(alpha, initial=0.0)
        self.ema_rot_y = EMA(alpha, initial=0.0)
        self.ema_rot_z = EMA(alpha, initial=0.0)
        self.ema_scale = EMA(alpha, initial=1.0)
        # Grab is smoothed more aggressively (higher alpha) since it's a
        # boolean signal -- we want it responsive, not sluggish, but still
        # debounced against a single noisy frame. initial=None so the very
        # first reading snaps straight to that value instead of being
        # dragged toward 0 and missing the >0.5 threshold on frame one.
        self.ema_grab = EMA(alpha=0.5, initial=None)

        self._last_state = {
            "rot_x": 0.0, "rot_y": 0.0, "rot_z": 0.0,
            "scale": 1.0, "grab": False,
        }

    @staticmethod
    def _dist(a, b):
        return math.hypot(a[0] - b[0], a[1] - b[1])

    def _hand_size(self, lm):
        return max(self._dist(lm[self.WRIST], lm[self.MIDDLE_MCP]), 1e-6)

    def _is_fist(self, lm):
        """A finger counts as 'curled' when its tip sits no farther from
        the wrist than its own MCP knuckle (i.e. it's folded back into the
        palm rather than extended). Fist == at least 3 of 4 fingers curled.
        Distance-from-wrist (rather than raw y-coordinate) makes this
        robust to hand rotation/tilt."""
        wrist = lm[self.WRIST]
        finger_pairs = [
            (self.INDEX_TIP, self.INDEX_MCP),
            (self.MIDDLE_TIP, self.MIDDLE_MCP),
            (self.RING_TIP, self.RING_MCP),
            (self.PINKY_TIP, self.PINKY_MCP),
        ]
        curled = 0
        for tip_idx, mcp_idx in finger_pairs:
            tip_dist = self._dist(wrist, lm[tip_idx])
            mcp_dist = self._dist(wrist, lm[mcp_idx])
            if tip_dist < mcp_dist * 1.15:
                curled += 1
        return curled >= 3

    def update(self, landmarks):
        lm = landmarks
        size = self._hand_size(lm)
        wrist = lm[self.WRIST]

        raw_grab = 1.0 if self._is_fist(lm) else 0.0
        grab = self.ema_grab.update(raw_grab) >= 0.5

        # Hand position relative to frame center -> target tilt angles.
        cx, cy = self.frame_w / 2.0, self.frame_h / 2.0
        dx = max(-1.0, min(1.0, (wrist[0] - cx) / (self.frame_w / 2.0)))
        dy = max(-1.0, min(1.0, (wrist[1] - cy) / (self.frame_h / 2.0)))
        target_rot_y = dx * self.max_angle
        target_rot_x = -dy * self.max_angle

        # Wrist -> middle-MCP vector angle -> target roll.
        mcp = lm[self.MIDDLE_MCP]
        angle = math.degrees(math.atan2(mcp[0] - wrist[0], -(mcp[1] - wrist[1])))
        target_rot_z = max(-45.0, min(45.0, angle))

        if grab:
            rot_x = self.ema_rot_x.update(target_rot_x)
            rot_y = self.ema_rot_y.update(target_rot_y)
            rot_z = self.ema_rot_z.update(target_rot_z)
        else:
            # Freeze rotation at its last smoothed value while not grabbing.
            rot_x, rot_y, rot_z = self.ema_rot_x.value, self.ema_rot_y.value, self.ema_rot_z.value

        # Thumb-index pinch distance, normalized by hand size so scale
        # doesn't drift just because the hand moved closer/farther.
        pinch = self._dist(lm[self.THUMB_TIP], lm[self.INDEX_TIP]) / size
        pinch = max(0.15, min(1.5, pinch))
        target_scale = float(np.interp(pinch, [0.15, 1.5], [0.4, 2.6]))
        scale = self.ema_scale.update(target_scale)

        state = {"rot_x": rot_x, "rot_y": rot_y, "rot_z": rot_z, "scale": scale, "grab": grab}
        self._last_state = state
        return state

    def hold(self):
        """No hand detected this frame: freeze the cube's last known
        transform instead of snapping it back to zero or crashing."""
        self._last_state["grab"] = False
        return dict(self._last_state)
